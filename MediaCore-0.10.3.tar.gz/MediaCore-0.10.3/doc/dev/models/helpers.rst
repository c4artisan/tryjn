.. _dev_models_helpers:

=============
Model Helpers
=============

Fetching Records
================

.. autofunction:: mediacore.model.fetch_row

Slugs
=====

.. autofunction:: mediacore.model.slugify

.. autofunction:: mediacore.model.get_available_slug


