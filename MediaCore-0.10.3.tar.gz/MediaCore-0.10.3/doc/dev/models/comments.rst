.. _dev_models_comments:

========
Comments
========

.. automodule:: mediacore.model.comments

Mapped Classes
--------------

.. autoclass:: Comment
   :members:

