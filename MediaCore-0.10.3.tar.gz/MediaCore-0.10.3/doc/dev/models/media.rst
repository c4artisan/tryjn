.. _dev_models_media:

=====
Media
=====

.. automodule:: mediacore.model.media

Mapped Classes
--------------

.. autoclass:: Media
   :members:

.. autoclass:: MediaFile
   :members:

Helpers
-------

Er, none here. TODO: finish this page.
