.. _dev_models_podcasts:

========
Podcasts
========

.. automodule:: mediacore.model.podcasts

Mapped Classes
--------------

.. autoclass:: Podcast
   :members:

Helpers
-------

Er, none here. TODO: finish this page.

