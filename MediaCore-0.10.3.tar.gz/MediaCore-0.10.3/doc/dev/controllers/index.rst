.. _dev_controllers_toplevel:

===========
Controllers
===========

.. automodule:: mediacore.controllers

.. toctree::

   public
   admin

