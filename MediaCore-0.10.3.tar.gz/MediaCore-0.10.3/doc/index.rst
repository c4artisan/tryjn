.. _toplevel:

MediaDrop Documentation
==========================

MediaDrop is a media-oriented content manager previously known as "MediaCore CE".


Contents
--------

.. toctree::
   :maxdepth: 3

   install/index
   install/upgrade
   user/index
   dev/index
   debugging/index
   glossary


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

