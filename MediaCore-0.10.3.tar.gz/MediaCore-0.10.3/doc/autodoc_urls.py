"""
Sphinx Extension for creating a map of URLs to controllers and templates

"""

def setup(app):
    pass
