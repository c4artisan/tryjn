.. _user_firststeps:

===========
First Steps
===========

You can explore the frontend and then try logging into the Admin area located at
http://localhost:8080/admin/ (or whatever the domain you're using). We've
created a default user, username **Admin**, password *admin*. Be sure to change
that in the settings right away!

