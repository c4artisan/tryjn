.. _user_admin_podcasts:

==================================
Podcast Management Admin Interface
==================================

A good first resource to get started with managing podcasts is the
`Creating a Podcast in MediaCore CE video <http://static.mediadrop.net/files/videos/tutorial-create-podcast-in-mediacore.mp4>`_.

